CREATE DATABASE music_store;
USE music_store;



-- 1. Genre and MediaType
CREATE TABLE Genre (
	genre_id INT PRIMARY KEY,
	name VARCHAR(120)
);





DESC Genre;

CREATE TABLE MediaType (
	media_type_id INT PRIMARY KEY,
	name VARCHAR(120)
);

DESC MediaType;

-- 2. Employee
CREATE TABLE Employee (
	employee_id INT PRIMARY KEY,
	last_name VARCHAR(120),
	first_name VARCHAR(120),
	title VARCHAR(120),
	reports_to INT,
  levels VARCHAR(255),
	birthdate DATE,
	hire_date DATE,
	address VARCHAR(255),
	city VARCHAR(100),
	state VARCHAR(100),
	country VARCHAR(100),
	postal_code VARCHAR(20),
	phone VARCHAR(50),
	fax VARCHAR(50),
	email VARCHAR(100)
);

DESC Employee;

-- 3. Customer
CREATE TABLE Customer (
	customer_id INT PRIMARY KEY,
	first_name VARCHAR(120),
	last_name VARCHAR(120),
	company VARCHAR(120),
	address VARCHAR(255),
	city VARCHAR(100),
	state VARCHAR(100),
	country VARCHAR(100),
	postal_code VARCHAR(20),
	phone VARCHAR(50),
	fax VARCHAR(50),
	email VARCHAR(100),
	support_rep_id INT,
	FOREIGN KEY (support_rep_id) REFERENCES Employee(employee_id)
);

-- 4. Artist
CREATE TABLE Artist (
	artist_id INT PRIMARY KEY,
	name VARCHAR(120)
);
DESC Artist;

-- 5. Album
CREATE TABLE Album (
	album_id INT PRIMARY KEY,
	title VARCHAR(160),
	artist_id INT,
	FOREIGN KEY (artist_id) REFERENCES Artist(artist_id)
);
DESC Album;

-- 6. Track
CREATE TABLE Track (
	track_id INT PRIMARY KEY,
	name VARCHAR(200),
	album_id INT,
	media_type_id INT,
	genre_id INT,
	composer VARCHAR(220),
	milliseconds INT,
	bytes INT,
	unit_price DECIMAL(10,2),
	FOREIGN KEY (album_id) REFERENCES Album(album_id),
	FOREIGN KEY (media_type_id) REFERENCES MediaType(media_type_id),
	FOREIGN KEY (genre_id) REFERENCES Genre(genre_id)
);

DESC Track;

-- 7. Invoice
CREATE TABLE Invoice (
	invoice_id INT PRIMARY KEY,
	customer_id INT,
	invoice_date DATE,
	billing_address VARCHAR(255),
	billing_city VARCHAR(100),
	billing_state VARCHAR(100),
	billing_country VARCHAR(100),
	billing_postal_code VARCHAR(20),
	total DECIMAL(10,2),
	FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);

DESC Invoice;

-- 8. InvoiceLine
CREATE TABLE InvoiceLine (
	invoice_line_id INT PRIMARY KEY,
	invoice_id INT,
	track_id INT,
	unit_price DECIMAL(10,2),
	quantity INT,
	FOREIGN KEY (invoice_id) REFERENCES Invoice(invoice_id),
	FOREIGN KEY (track_id) REFERENCES Track(track_id)
);
DESC iNVOICELINE;

-- 9. Playlist
CREATE TABLE Playlist (
 	playlist_id INT PRIMARY KEY,
	name VARCHAR(255)
);
DESC Playlist;

-- 10. PlaylistTrack
CREATE TABLE PlaylistTrack (
	playlist_id INT,
	track_id INT,
	PRIMARY KEY (playlist_id, track_id),
	FOREIGN KEY (playlist_id) REFERENCES Playlist(playlist_id),
	FOREIGN KEY (track_id) REFERENCES Track(track_id)
);

DESC PlaylistTrack;
-- 
SELECT * FROM PlaylistTrack;
SELECT * FROM customer;
-- Who is the senior most employee based on job title?
SELECT *
FROM Employee 
ORDER BY levels DESC
LIMIT 1;

--  Which countries have the most Invoices?
SELECT BILLING_COUNTRY
FROM INVOICE
GROUP BY BILLING_COUNTRY 
LIMIT 1;

--  What are the top 3 values of total invoice?
SELECT total
FROM INVOICE
ORDER BY total DESC
LIMIT 3;

-- Which city has the best customers? - We would like to throw a promotional Music Festival 
-- in the city we made the most money. Write a query that returns one city that has the highest
-- sum of invoice totals. Return both the city name & sum of all invoice totals

SELECT SUM(TOTAL) AS TOTAL_INVOICE,BILLING_CITY
FROM INVOICE
GROUP BY BILLING_CITY
ORDER BY TOTAL_INVOICE DESC
LIMIT 1;

--  Who is the best customer? - The customer who has spent the most money will be declared the
-- best customer. Write a query that returns the person who has spent the most money
SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    SUM(i.total) AS total_spent
FROM Customer c
JOIN Invoice i
    ON c.customer_id = i.customer_id
GROUP BY c.customer_id, c.first_name, c.last_name
ORDER BY total_spent DESC
LIMIT 1;
	

-- Write a query to return the email, first name, last name, & Genre of all Rock Music listeners. 
-- Return your list ordered alphabetically by email starting with A
SELECT DISTINCT
    c.email,
    c.first_name,
    c.last_name,
    g.name AS genre
FROM Customer c
JOIN Invoice i 
    ON c.customer_id = i.customer_id
JOIN InvoiceLine il 
    ON i.invoice_id = il.invoice_id
JOIN Track t 
    ON il.track_id = t.track_id
JOIN Genre g 
    ON t.genre_id = g.genre_id
WHERE g.name = 'Rock'
ORDER BY c.email ASC;

--  Let's invite the artists who have written the most rock music in our dataset. 
-- Write a query that returns the Artist name and total track count of the top 10 rock bands 
SELECT 
    ar.name AS artist_name,
    COUNT(t.track_id) AS rock_track_count
FROM Artist ar
JOIN Album al 
    ON ar.artist_id = al.artist_id
JOIN Track t 
    ON al.album_id = t.album_id
JOIN Genre g 
    ON t.genre_id = g.genre_id
WHERE g.name = 'Rock'
GROUP BY ar.artist_id, ar.name
ORDER BY rock_track_count DESC
LIMIT 10;


--  Return all the track names that have a song length longer than the average song length.- 
-- Return the Name and Milliseconds for each track. Order by the song length, with the longest songs listed first

SELECT 
    name,
    milliseconds
FROM Track
WHERE milliseconds > (
    SELECT AVG(milliseconds)
    FROM Track
)
ORDER BY milliseconds DESC;

-- . Find hw much amount is spent by each customer on artists? Write a query to return customer name, artist name and total spent 
SELECT
    CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
    ar.name AS artist_name,
    SUM(il.unit_price * il.quantity) AS total_spent
FROM Customer c
JOIN Invoice i
    ON c.customer_id = i.customer_id
JOIN InvoiceLine il
    ON i.invoice_id = il.invoice_id
JOIN Track t
    ON il.track_id = t.track_id
JOIN Album al
    ON t.album_id = al.album_id
JOIN Artist ar
    ON al.artist_id = ar.artist_id
GROUP BY c.customer_id, ar.artist_id
ORDER BY total_spent DESC;

-- We want to find out the most popular music Genre for each country. We determine the most popular genre as the genre with the highest amount of purchases.
--  Write a query that returns each country along with the top Genre. For countries where the maximum number of purchases is shared, return all Genres

WITH genre_counts AS (
    SELECT
        c.country,
        g.name AS genre_name,
        COUNT(il.invoice_line_id) AS purchase_count
    FROM Customer c
    JOIN Invoice i 
        ON c.customer_id = i.customer_id
    JOIN InvoiceLine il 
        ON i.invoice_id = il.invoice_id
    JOIN Track t 
        ON il.track_id = t.track_id
    JOIN Genre g 
        ON t.genre_id = g.genre_id
    GROUP BY c.country, g.genre_id, g.name
),

ranked AS (
    SELECT *,
           RANK() OVER (
               PARTITION BY country
               ORDER BY purchase_count DESC
           ) AS rnk
    FROM genre_counts
)

SELECT
    country,
    genre_name,
    purchase_count
FROM ranked
WHERE rnk = 1
ORDER BY country;


--  Write a query that determines the customer that has spent the most on music for each country. 
-- Write a query that returns the country along with the top customer and how much they spent.
--  For countries where the top amount spent is shared, provide all customers who spent this amount
WITH customer_spending AS (
    SELECT
        c.country,
        c.customer_id,
        CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
        SUM(i.total) AS total_spent
    FROM Customer c
    JOIN Invoice i
        ON c.customer_id = i.customer_id
    GROUP BY c.country, c.customer_id, c.first_name, c.last_name
),

ranked AS (
    SELECT *,
           RANK() OVER (
               PARTITION BY country
               ORDER BY total_spent DESC
           ) AS rnk
    FROM customer_spending
)

SELECT
    country,
    customer_name,
    total_spent
FROM ranked
WHERE rnk = 1
ORDER BY country;

USE music_store;
SELECT * FROM EMPLOYEE;

WITH genre_sales AS (
    SELECT
        i.billing_country AS country,
        g.name AS genre,
        COUNT(il.invoiceline_id) AS purchases,
        RANK() OVER(
            PARTITION BY i.billing_country
            ORDER BY COUNT(il.invoiceline_id) DESC
        ) AS rnk
    FROM invoice i
    JOIN invoice_line il ON i.invoice_id = il.invoice_id
    JOIN track t ON il.track_id = t.track_id
    JOIN genre g ON t.genre_id = g.genre_id
    GROUP BY i.billing_country, g.name
)

SELECT country, genre, purchases
FROM genre_sales
WHERE rnk = 1
ORDER BY country;


WITH genre_sales AS (
    SELECT
        i.billing_country AS country,
        g.name AS genre,
        COUNT(il.invoice_line_id) AS purchases,
        RANK() OVER(
            PARTITION BY i.billing_country
            ORDER BY COUNT(il.invoice_line_id) DESC
        ) AS rnk
    FROM invoice i
    JOIN InvoiceLine il ON i.invoice_id = il.invoice_id
    JOIN track t ON il.track_id = t.track_id
    JOIN genre g ON t.genre_id = g.genre_id
    GROUP BY i.billing_country, g.name
)

SELECT country, genre, purchases
FROM genre_sales
WHERE rnk = 1
ORDER BY country;




